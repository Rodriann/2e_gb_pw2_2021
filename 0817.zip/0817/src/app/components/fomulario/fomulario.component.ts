import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fomulario',
  templateUrl: './fomulario.component.html',
  styleUrls: ['./fomulario.component.css']
})
export class FomularioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
